return {
	name = 'KickingKobolds',
	config = '',
	platform = 'win64',
	version = '0.01',
	love = '12.0'
}