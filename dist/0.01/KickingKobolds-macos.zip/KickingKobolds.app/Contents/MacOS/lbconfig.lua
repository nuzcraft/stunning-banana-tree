return {
	name = 'KickingKobolds',
	config = '',
	platform = 'macos',
	version = '0.01',
	love = '12.0'
}